/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicaciones;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Alumnos
 */
public class ImagenCliente {
    private String titulo;

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    
    public void envia(){
        try {
            Socket cliente = new Socket("localhost", 4000);//direccion y puerto
            PrintStream envio = new PrintStream(cliente.getOutputStream());
            /**
             * envia: obtiene el flujo de salida del cliente y se lo asigna aun
             * PrintStream
             */
            
            String ruta = getTitulo();
            FileInputStream origen = new FileInputStream(ruta);
            /**
             * FileInputStream lee el archivo, se le pasa la ruta para que leea
             * el archivo
             */
            byte[] buffer = new byte[1024];//arreglo de bytes
            int len;
            /**
             * el clico le asigna a la variable len lo que lee del origen y lo
             * compara mientras sea mayor a cero lo va enviando, hasta que
             * termine de leer todo el archivo; una vez que termina el cliclo se
             * cierra el objeto y el socket
             */
            while ((len = origen.read(buffer)) > 0) {
                envio.write(buffer, 0, len);
            }
            envio.close();
            cliente.close();
        } catch (IOException ex) {
            Logger.getLogger(ClienteFile.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
