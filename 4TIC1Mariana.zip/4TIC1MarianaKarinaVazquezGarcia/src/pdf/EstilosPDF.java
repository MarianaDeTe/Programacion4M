/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pdf;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;

/**
 * Mariana Karina Vazquez Garcia
 */
public class EstilosPDF {

    private String titulo;
    private String parrafo;
    private int futi;
    private int coti;
    private int fupa;
    private int copa;

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getParrafo() {
        return parrafo;
    }

    public void setParrafo(String parrafo) {
        this.parrafo = parrafo;
    }

    public int getFuti() {
        return futi;
    }

    public void setFuti(int futi) {
        this.futi = futi;
    }

    public int getCoti() {
        return coti;
    }

    public void setCoti(int coti) {
        this.coti = coti;
    }

    public int getFupa() {
        return fupa;
    }

    public void setFupa(int fupa) {
        this.fupa = fupa;
    }

    public int getCopa() {
        return copa;
    }

    public void setCopa(int copa) {
        this.copa = copa;
    }

    public void Generar() {
        try {
            Document documento = new Document(PageSize.LETTER);
            PdfWriter.getInstance(documento, new FileOutputStream("Estilos.pdf"));
            
            documento.open();
            
            switch (futi) {
                case 1:
                    Paragraph parrafo = new Paragraph();
                    Font fuente = new Font(Font.FontFamily.HELVETICA, 30, Font.ITALIC);
                    switch (coti) {
                        case 1:
                            fuente.setColor(BaseColor.BLUE);
                            parrafo.setFont(fuente);
                            parrafo.setAlignment(Element.ALIGN_CENTER);
                            parrafo.add(getTitulo());
                            documento.add(parrafo);
                            break;
                        case 2:
                            fuente.setColor(BaseColor.PINK);
                            parrafo.setFont(fuente);
                            parrafo.setAlignment(Element.ALIGN_CENTER);
                            parrafo.add(getTitulo());
                            documento.add(parrafo);
                            break;
                        case 3:

                            fuente.setColor(BaseColor.GREEN);
                            parrafo.setFont(fuente);
                            parrafo.setAlignment(Element.ALIGN_CENTER);
                            parrafo.add(getTitulo());
                            documento.add(parrafo);
                            break;
                    }
                    break;
                case 2:
                    Paragraph parraf = new Paragraph();
                    Font fuent = new Font(Font.FontFamily.ZAPFDINGBATS, 30, Font.BOLD);
                    switch (coti) {
                        case 1:
                            fuent.setColor(BaseColor.BLUE);
                            parraf.setFont(fuent);
                            parraf.setAlignment(Element.ALIGN_CENTER);
                            parraf.add(getTitulo());
                            documento.add(parraf);
                            break;
                        case 2:
                            fuent.setColor(BaseColor.PINK);
                            parraf.setFont(fuent);
                            parraf.setAlignment(Element.ALIGN_CENTER);
                            parraf.add(getTitulo());
                            documento.add(parraf);
                            break;
                        case 3:
                            fuent.setColor(BaseColor.GREEN);
                            parraf.setFont(fuent);
                            parraf.setAlignment(Element.ALIGN_CENTER);
                            parraf.add(getTitulo());
                            documento.add(parraf);
                            break;
                    }
                    break;
            }
            documento.add(new Paragraph("\n"));
            switch (fupa) {
                case 1:
                    Paragraph parrafo = new Paragraph();
                    Font fuente = new Font(Font.FontFamily.COURIER, 20, Font.BOLDITALIC);
                    switch (copa) {
                        case 1:
                            fuente.setColor(BaseColor.RED);
                            parrafo.setFont(fuente);
                            parrafo.setAlignment(Element.ALIGN_JUSTIFIED);
                            parrafo.add(getParrafo());
                            documento.add(parrafo);
                            break;
                        case 2:
                            fuente.setColor(BaseColor.GRAY);
                            parrafo.setFont(fuente);
                            parrafo.setAlignment(Element.ALIGN_JUSTIFIED);
                            parrafo.add(getParrafo());
                            documento.add(parrafo);
                            break;
                        case 3:
                            fuente.setColor(BaseColor.ORANGE);
                            parrafo.setFont(fuente);
                            parrafo.setAlignment(Element.ALIGN_JUSTIFIED);
                            parrafo.add(getParrafo());
                            documento.add(parrafo);
                            break;
                    }
                    break;
                case 2:

                    Paragraph parraf = new Paragraph();
                    Font fuent = new Font(Font.FontFamily.UNDEFINED, 20, Font.BOLD);
                    switch (copa) {
                        case 1:
                            fuent.setColor(BaseColor.RED);
                            parraf.setFont(fuent);
                            parraf.setAlignment(Element.ALIGN_JUSTIFIED);
                            parraf.add(getParrafo());
                            documento.add(parraf);
                            break;
                        case 2:
                            fuent.setColor(BaseColor.GRAY);
                            parraf.setFont(fuent);
                            parraf.setAlignment(Element.ALIGN_JUSTIFIED);
                            parraf.add(getParrafo());
                            documento.add(parraf);
                            break;
                        case 3:
                            fuent.setColor(BaseColor.ORANGE);
                            parraf.setFont(fuent);
                            parraf.setAlignment(Element.ALIGN_JUSTIFIED);
                            parraf.add(getParrafo());
                            documento.add(parraf);
                            break;
                    }
                    break;
            }
            documento.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
