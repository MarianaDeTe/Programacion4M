/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenUno;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *Vazquez Garcia Mariana Karina
 */
public class PropiedadesExamen {
    
    private int id;
    private String nombre;
    private String paterno;
    private String materno;
    private String curp;

    /**
     * @return the id
     */
    public int getId() {
        if (id == 0) {
            JOptionPane.showMessageDialog(null, "No existe el Id", "Error (°n°)", JOptionPane.ERROR_MESSAGE);
        }
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPaterno() {
        return paterno;
    }

    /**
     * @param paterno the paterno to set
     */
    public void setPaterno(String paterno) {
        this.paterno = paterno;
    }

    public String getMaterno() {
        return materno;
    }

    public void setMaterno(String materno) {
        this.materno = materno;
    }
    
    public void Busqueda(){
        try {
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("Examen Mariana Karina Vazquez Garcia.pdf"));

            doc.open();

            Conexion con = new Conexion();
            Statement sentencia = con.obtenerConexion().createStatement();
            String sql = "SELECT * FROM persona WHERE personaId=" + id;
            ResultSet resultados = sentencia.executeQuery(sql);

            Paragraph col = new Paragraph(getId());
            Font fuente = new Font(Font.FontFamily.TIMES_ROMAN, 5, Font.ITALIC);
            fuente.setColor(BaseColor.YELLOW);
            col.setFont(fuente);
            col.add(getCurp());
            doc.add(col);
            
            
            
            PdfPCell celda = new PdfPCell();
            celda.setColspan(3);
            Paragraph parrafo = new Paragraph("Registro encontrado");
            Paragraph numero = new Paragraph("N°");
            Paragraph nom = new Paragraph("Nombre");
            Paragraph curp = new Paragraph("Curp");
            parrafo.setAlignment(Element.ALIGN_CENTER);
            celda.addElement(parrafo);
            
            PdfPTable inicia = new PdfPTable(3);
            inicia.addCell(celda);
            inicia.addCell(numero);
            inicia.addCell(nom);
            inicia.addCell(curp);
            
            doc.add(inicia);
            
//            if (getId() != 2) {
//                    Paragraph inpar = new Paragraph(getCurp());
////                    Font fuente = new Font(Font.FontFamily.TIMES_ROMAN, 10, Font.ITALIC); 
//                    fuente.setColor(BaseColor.RED);
//                            inpar.setFont(fuente);
//                            inpar.add(resultados.getString("curp"));
//                            doc.add(inpar);
//                }else{
//                    JOptionPane.showMessageDialog(null, "No hay color", "Error ", JOptionPane.ERROR_MESSAGE);
//                }

            while (resultados.next()) {
                
                PdfPTable miTabla = new PdfPTable(3);
                
                miTabla.addCell(new Phrase(resultados.getString("personaId")));
                miTabla.addCell(new Phrase(resultados.getString("nombre") + " " + resultados.getString("paterno") + " " + resultados.getString("materno")));
                
                miTabla.addCell(new Phrase(resultados.getString("curp")));
                doc.add(miTabla);
            }
            doc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void BuscarP() {
        try {
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("Examen Mariana Karina Vazquez Garcia.pdf"));
            doc.open();

            Conexion objCon = new Conexion();
            Statement sentencia = objCon.obtenerConexion().createStatement();
            String sql = "SELECT * FROM persona WHERE Nombre='" + nombre + "' or paterno='"
                    + paterno + "' or materno='" + materno + "'";
            ResultSet resultados = sentencia.executeQuery(sql);

            Paragraph col = new Paragraph(getPaterno());
            Font fuente = new Font(Font.FontFamily.TIMES_ROMAN, 5, Font.ITALIC);
            fuente.setColor(BaseColor.RED);
            col.setFont(fuente);
            col.add(getCurp());
            doc.add(col);
            
            PdfPCell celda = new PdfPCell();
            celda.setColspan(3);

            Paragraph parrafo = new Paragraph("Registros encontrados");
            Paragraph num = new Paragraph("N°");
            Paragraph no = new Paragraph("Nombre");
            Paragraph cu = new Paragraph("Curp");

            parrafo.setAlignment(Element.ALIGN_CENTER);
            celda.addElement(parrafo);

            PdfPTable Tabla = new PdfPTable(3);
            Tabla.addCell(celda);
            Tabla.addCell(num);
            Tabla.addCell(no);
            Tabla.addCell(cu);
            doc.add(Tabla);

            while (resultados.next()) {
                PdfPTable resTabla = new PdfPTable(3);
                
                resTabla.addCell(new Phrase(resultados.getString("personaId")));
                resTabla.addCell(new Phrase(resultados.getString("nombre") + " " + resultados.getString("paterno") + " " + resultados.getString("materno")));
                resTabla.addCell(new Phrase(resultados.getString("curp")));

                doc.add(resTabla);
            }
            doc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @return the curp
     */
    public String getCurp() {
        return curp;
    }

    /**
     * @param curp the curp to set
     */
    public void setCurp(String curp) {
        this.curp = curp;
    }
    }

