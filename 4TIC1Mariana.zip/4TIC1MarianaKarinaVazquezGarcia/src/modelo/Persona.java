/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import conexiones.Conexion;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 * Mariana Karina Vazquez Garcia
 */
public class Persona {

    private String nombre, paterno, materno, curp;
    private int personaid;
    static Statement sentencia;//procesa una sentencia sql

    /**
     * Los get se encargan de recuperar la información que se registra en los
     * cuadros que se le agregan al formulario.
     *
     * Los set se encargan de enviar la información y con el objeto de conexion
     * lo envian desde la base de datos.
     */
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPaterno() {
        return paterno;
    }

    public void setPaterno(String paterno) {
        this.paterno = paterno;
    }

    public String getMaterno() {
        return materno;
    }

    public void setMaterno(String materno) {
        this.materno = materno;
    }

    public String getCurp() {
        return curp;
    }

    public void setCurp(String curp) {
        this.curp = curp;
    }

    /**
     * Valida, si no encuentra el id en la base de datos devuelve un mensaje de
     * error
     *
     * @return
     */
    public int getPersonaid() {
        if (personaid == 0) {
            JOptionPane.showMessageDialog(null, "No existe ese ID", "Error (°n°)", JOptionPane.ERROR_MESSAGE);
        }
        return personaid;
    }

    public void setPersonaid(int personaid) {
        this.personaid = personaid;
    }

    public Persona(String xNombre) {
        nombre = xNombre;
    }

    public Persona() {//sin ningun parametro
    }

    public Persona(int xPersonaid) {
        personaid = xPersonaid;
        obtenerPersona();
    }

    public boolean obtenerPersona() {
        try {
            Conexion objCon = new Conexion();
            String sql = "SELECT * FROM Persona where Personaid=" + personaid;
            Statement sentencia = objCon.obtenerConexion().createStatement();
            ResultSet registro = sentencia.executeQuery(sql);
            //ResultSet muestra los datos de una columna correspondiente a una fila
            while (registro.next()) {
                nombre = registro.getString("Nombre");
                paterno = registro.getString(3);
                materno = registro.getString(4);
                curp = registro.getString(5);

            }
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();//imprime en la consola, las excepciones
        }
        return false;
    }

    public boolean getPersonaByPreparedStatement(int xPersona) {
        //Un PreparedStatement se utiliza para sentencias que se tienen que precompilar
        try {
            String sql = "SELECT * FROM Persona where Personaid=?";
            Conexion objCon = new Conexion();
            PreparedStatement ps = objCon.obtenerConexion().prepareStatement(sql);
            ps.setInt(1, xPersona);//asigna los valores al PreparedStatement
            ResultSet registro = ps.executeQuery();

            while (registro.next()) {
                personaid = registro.getInt(1);
                /**
                 * dentro del get se colocan los campos que estan en la base de
                 * datos
                 */
                nombre = registro.getString(2);
                paterno = registro.getString("paterno");
                materno = registro.getString("materno");
                curp = registro.getString("curp");
            }
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public boolean getPersonaEliminaByPreparedStatement(int xPersona) {
        try {
            String sql = "DELETE FROM Persona where Personaid=?";
            Conexion objCon = new Conexion();
            PreparedStatement ps = objCon.obtenerConexion().prepareStatement(sql);//define una sentencia
            ps.setInt(1, xPersona);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Eliminación exitosa", "Felicidades (°U°)", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "No se pudo eliminar " + ex, "Error (°n°)", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }

    public boolean getPersonaBuscaByCalleble(int xPersona) {
        //Un Calleble hace el llamado a los procedimientos almacenados
        try {
            Conexion objCon = new Conexion();
            CallableStatement cs = objCon.obtenerConexion().prepareCall("{Call buscarPersona(?)}");
            cs.setInt(1, xPersona);
            ResultSet registro = cs.executeQuery();

            while (registro.next()) {//continua buscando el siguiente registro
                personaid = registro.getInt(1);
                nombre = registro.getString("Nombre");
                paterno = registro.getString(3);
                materno = registro.getString(4);
                curp = registro.getString(5);
            }
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public boolean getPersonaAgregaByCalleble(int xPersona, String xNombre, String paterno, String materno, String curp) {
        try {
            Conexion objCon = new Conexion();
            CallableStatement cs = objCon.obtenerConexion().prepareCall("{Call insertarDatos(?,?,?,?,?)}");
            cs.setInt(1, xPersona);
            cs.setString(2, this.getNombre());
            cs.setString(3, this.getPaterno());
            cs.setString(4, this.getMaterno());
            cs.setString(5, this.getCurp());

            cs.executeQuery();

            JOptionPane.showMessageDialog(null, "Registro exitoso", "Felicidades (°U°)", JOptionPane.INFORMATION_MESSAGE);

            return true;
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "No se pudo insertar " + ex, "Error (°n°)", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }

    public boolean getPersonaActualizaByCalleble(int xPersona, String xNombre, String paterno, String materno, String curp) {
        try {
            Conexion objCon = new Conexion();
            CallableStatement cs = objCon.obtenerConexion().prepareCall("{Call modificarPersona(?,?,?,?,?)}");
            cs.setInt(1, xPersona);
            cs.setString(2, this.getNombre());
            cs.setString(3, this.getPaterno());
            cs.setString(4, this.getMaterno());
            cs.setString(5, this.getCurp());

            cs.executeUpdate();

            JOptionPane.showMessageDialog(null, "Actualizacion exitosa", "Felicidades (°U°)", JOptionPane.INFORMATION_MESSAGE);

            return true;
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "No se pudo actualizar " + ex, "Error (°n°)", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }

}

//    public void EliminarPersona(){
//        Connection cn;
//        PreparedStatement pst;
//        CallableStatement cs;
//        try{
//            Conexion objConexion = new Conexion();
//            cn = objConexion.obtenerConexion();
//            cs = cn.prepareCall("call eliminarPersona(?)");
//            cs.setInt(1, this.getPersonaid());
//            int res = cs.executeUpdate();
//            if (res == 1) {
//                JOptionPane.showMessageDialog(null, "Registro exitoso", "Felicidades", JOptionPane.INFORMATION_MESSAGE);
//            }
//        }catch(Exception e){
//            JOptionPane.showMessageDialog(null, "No se pudo insertar " + e, "Error", JOptionPane.ERROR_MESSAGE);
//        }
//    }
//    
//    public void AgregarPersona(){
//        Connection cn;
//        PreparedStatement pst;
//        try{
//            Conexion objConexion = new Conexion();
//            cn = objConexion.obtenerConexion();
//            pst = cn.prepareCall("call insertarDatos(?,?,?,?,?)");
//            pst.setString(1, (null));
//            pst.setString(2, this.getNombre());
//            pst.setString(3, this.getPaterno());
//            pst.setString(4, this.getMaterno());
//            pst.setString(5, this.getCurp());
//            int res = pst.executeUpdate();
//            if (res == 1) {
//                JOptionPane.showMessageDialog(null, "Registro exitoso", "Felicidades", JOptionPane.INFORMATION_MESSAGE);
//            }
//        }catch(Exception e){
//            JOptionPane.showMessageDialog(null, "No se pudo insertar " + e, "Error", JOptionPane.ERROR_MESSAGE);
//        }
//    }
//    
//    public void ModificarPersona(){
//        Connection cn;
//        PreparedStatement pst;
//        try{
//            Conexion objConexion = new Conexion();
//            cn = objConexion.obtenerConexion();
//            pst = cn.prepareCall("call modificarPersona(?,?,?,?,?)");
//            pst.setInt(1, this.getPersonaid());
//            pst.setString(2, this.getNombre());
//            pst.setString(3, this.getPaterno());
//            pst.setString(4, this.getMaterno());
//            pst.setString(5, this.getCurp());
//            int res = pst.executeUpdate();
//            if (res == 1) {
//                JOptionPane.showMessageDialog(null, "Registro exitoso", "Felicidades", JOptionPane.INFORMATION_MESSAGE);
//            }
//        }catch(Exception e){
//            JOptionPane.showMessageDialog(null, "No se pudo insertar " + e, "Error", JOptionPane.ERROR_MESSAGE);
//        }
//    }
