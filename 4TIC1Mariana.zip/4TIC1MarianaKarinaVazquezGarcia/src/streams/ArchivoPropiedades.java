/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package streams;

import java.io.File;
import javax.swing.JOptionPane;

/**
 * Vazquez Garcia Mariana Karina
 */
public class ArchivoPropiedades {

    private String nombre = null, url = null;
    private boolean ar = false;
    private boolean di = false;
    private boolean lec = false;
    private boolean esc = false;
    private boolean ex = false;
    private boolean oc = false;

    public void genera() {
        File archivo = new File(getNombre());
        setUrl(archivo.getAbsolutePath());

        if (!archivo.exists()) {
            JOptionPane.showMessageDialog(null, "No se encuentra el archivo", "Error (ºnº)", JOptionPane.ERROR_MESSAGE);
            url = "No hay ruta";
            ar = false;
            di = false;
            lec = false;
            esc = false;
            ex = false;
            oc = false;
//            if (archivo.createNewFile()) {
//                JOptionPane.showMessageDialog(null, "El archivo " + getNombre() + " se ha creado", "Felicidades (ºUº)", JOptionPane.INFORMATION_MESSAGE);
        } else {
//                JOptionPane.showMessageDialog(null, "No se pudo crear el archivo" + getNombre(), "Error (ºnº)", JOptionPane.ERROR_MESSAGE);

            if (archivo.isFile() == true) {
                ar = archivo.isFile();
            }else{
                ar = false;
            }

            if (archivo.isDirectory()) {
                di = archivo.isDirectory();
            }

            if (archivo.canRead()) {
                lec = archivo.canRead();
            }

            if (archivo.canWrite()) {
                esc = archivo.canWrite();
            }

            if (archivo.canExecute()) {
                ex = archivo.canExecute();
            }

            if (archivo.isHidden()) {
                oc = archivo.isHidden();
            }
        }
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre + ".txt";
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public boolean getDi() {
        return di;
    }

    public void setDi(boolean di) {
        this.di = di;
    }

    public boolean getLec() {
        return lec;
    }

    public void setLec(boolean lec) {
        this.lec = lec;
    }

    public boolean getEsc() {
        return esc;
    }

    public void setEsc(boolean esc) {
        this.esc = esc;
    }

    public boolean getEx() {
        return ex;
    }

    public void setEx(boolean ex) {
        this.ex = ex;
    }

    public boolean getOc() {
        return oc;
    }

    public void setOc(boolean oc) {
        this.oc = oc;
    }

    public boolean getAr() {
        return ar;
    }

    public void setAr(boolean ar) {
        this.ar = ar;
    }
}
