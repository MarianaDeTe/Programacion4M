/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicaciones;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Vazquez Garcia Mariana Karina
 */
public class PdfClientep {

    private String titulo;
    private String parrafo;

    public String getTitulo() {
        return titulo + ".pdf";
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getParrafo() {
        return parrafo;
    }

    public void setParrafo(String parrafo) {
        this.parrafo = parrafo;
    }

    public void PrimerPDF() {
        try {
            Document documento = new Document(PageSize.LETTER);
            PdfWriter.getInstance(documento, new FileOutputStream(getTitulo()));
            documento.open();
            documento.add(new Paragraph(getParrafo()));
            documento.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void envia() {
        try {
            Socket cliente = new Socket("10.11.4.116", 4000);
            PrintStream envio = new PrintStream(cliente.getOutputStream());
            String ruta = "G:\\Rojita\\4TIC1\\Desarrollo de Aplicaciones II\\4TIC1MarianaKarinaVazquezGarcia\\" + getTitulo();
            /**
             * En la ruta se guarda la direccion donde se encuentra el pdf mas
             * la extencion, que en este caso es la que recupera del cuadro de
             * texto de la vista mas la extencion ".pdf"
             */
            FileInputStream origen = new FileInputStream(ruta);//leer el archivo
            byte[] buffer = new byte[1024];//tamaño del archivo
            int len;
            /**
             * el clico le asigna a la variable len lo que lee del origen y lo
             * compara mientras sea mayor a cero lo va enviando, hasta que
             * termine de leer todo el archivo; una vez que termina el cliclo se
             * cierra el objeto y el socket
             */
            while ((len = origen.read(buffer)) > 0) {
                envio.write(buffer, 0, len);
            }
            envio.close();
            cliente.close();
        } catch (IOException ex) {
            Logger.getLogger(ClienteFile.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
