/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package streams;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;

/**
 *
 * @author Alumnos
 */
public class ArcBinarioPropiedades {

    private String nom;
    private String mensaje;

    public void PDF() {
        try {
            Document documento = new Document(PageSize.LETTER);
            PdfWriter.getInstance(documento, new FileOutputStream(getNom() + ".pdf"));
            documento.open();
            documento.add(new Paragraph(getMensaje()));
            documento.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void Texto() {
        if (getNom() == null) {

        } else {
            try {
                FileWriter archivo = new FileWriter(getNom() + ".txt");
                archivo.write(getMensaje());
                archivo.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void Binario() {
        try {
            DataOutputStream arcSalida = new DataOutputStream(new FileOutputStream(getNom() + ".dat"));
            arcSalida.writeUTF(getMensaje());
            arcSalida.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @return the nom
     */
    public String getNom() {
        return nom;
    }

    /**
     * @param nom the nom to set
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * @return the mensaje
     */
    public String getMensaje() {
        return mensaje;
    }

    /**
     * @param mensaje the mensaje to set
     */
    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
}
