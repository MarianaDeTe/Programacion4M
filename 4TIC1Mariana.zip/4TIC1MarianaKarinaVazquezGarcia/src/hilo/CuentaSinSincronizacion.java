/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilo;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author Alumnos
 */
public class CuentaSinSincronizacion {

    private static final Cuenta monto = new Cuenta();

    public static void main(String args[]) {
        ExecutorService executor = Executors.newCachedThreadPool();
        for (int i = 0; i < 100; i++) {
            executor.execute(new AgregarCentavo());
        }
        executor.shutdown();
        System.out.println("Cual es el balance ? " + monto.getBalance());
    }

    private static class AgregarCentavo implements Runnable {
        public void run() {
            monto.depositar(1);
        }
    }

    private static class Cuenta {
//los hilos actualizan el balance
        private int balance = 0;

        public int getBalance() {
            return balance;
        }

        public synchronized void depositar(int cantidad) {
            int newBalance = balance + cantidad;
            try {
                Thread.sleep(1);//mientras mas se duerme el hilo, mayor es la latencia.
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
            balance = newBalance;
        }
    }
}
