/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilo;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;

/**
 *Vazquez Garcia Mariana Karina
 * 
 * Método para la creación de un PDF, con gran cantidad de  párrafos.
 */
public class BigPdf {

    public void genera(){
        try{
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("prueba.pdf"));
            doc.open();
            for (int i = 0; i <= 30000; i++) {
                doc.add(new Paragraph("Numero" + i));
            }
            doc.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
