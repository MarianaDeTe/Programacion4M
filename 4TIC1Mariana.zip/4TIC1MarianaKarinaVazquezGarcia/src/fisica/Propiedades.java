/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fisica;

/**
 * Mariana Karina Vazquez Garcia
 */
public class Propiedades {

    double fuerza;
    double masa;
    double acelera;

    /**
     * @return the fuerza
     * 
     * recupera el texto ingresado 
     */
    public double getFuerza() {
        return fuerza = masa * acelera;
    }

    /**
     * @param fuerza the fuerza to set
     * 
     * envia el texto recuperado
     */
    public void setFuerza(double fuerza) {
        this.fuerza = fuerza;
    }

    /**
     * @return the masa
     */
    public double getMasa() {
        return masa = fuerza / acelera;
    }

    /**
     * @param masa the masa to set
     */
    public void setMasa(double masa) {
        this.masa = masa;
    }

    /**
     * @return the acelera
     */
    public double getAcelera() {
        return acelera = fuerza / masa;
    }

    /**
     * @param acelera the acelera to set
     */
    public void setAcelera(double acelera) {
        this.acelera = acelera;
    }
}
