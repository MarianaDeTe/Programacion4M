/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;

/**
 *
 * @author Alumnos
 */
public class TercerPDF {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            Paragraph parrafo = new Paragraph("Titulo del documento");
            Document documento = new Document(PageSize.LETTER);
            PdfWriter.getInstance(documento, new FileOutputStream("tercerPdf.pdf"));
            documento.open();
            parrafo.setFont(new Font(Font.FontFamily.SYMBOL, 40, Font.ITALIC));//cambia el tipo de letra
            parrafo.setAlignment(Element.ALIGN_CENTER);
            /**
             * Se crea una instancia para guardar a el primer paragraph(parrafo)
             * para haci enviarle una alineacion.
             */
            documento.add(parrafo);
            for (int i = 0; i <= 10; i++) {
                Paragraph p = new Paragraph("Parrafo No. " + i + " desde el ciclo for");
//                documento.add(new Paragraph("Parrafo No. " + i + " desde el ciclo for"));
                p.setAlignment(Element.ALIGN_RIGHT);
                p.setFont(new Font(Font.FontFamily.SYMBOL, 40, Font.ITALIC));
                documento.add(p);//agrega p = PARAGRAPH
            }
            documento.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
