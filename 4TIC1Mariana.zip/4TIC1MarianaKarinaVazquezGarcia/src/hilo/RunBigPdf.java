/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilo;

/**
 *Vazquez Garcia Mariana Karina
 *
 * La clase Thread tiene varios constructores, además del constructor por
 * defecto (sin argumentos).
 */
public class RunBigPdf extends Thread {
//El método run es el corazón del subproceso, es donde tiene lugar la acción del subproceso.

    public void run() {
        BigPdf bp = new BigPdf();
        bp.genera();
    }
}
