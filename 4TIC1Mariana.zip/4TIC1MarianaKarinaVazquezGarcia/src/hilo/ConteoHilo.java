/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilo;

import java.io.File;

/**
 *
 * @author Alumnos
 */
public class ConteoHilo extends Thread {

    private String ruta;
    private int archi = 0;
    private int dire = 0;

    /**
     * @return the ruta
     */
    public String getRuta() {
        return ruta;
    }

    /**
     * @param ruta the ruta to set
     */
    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    /**
     * @return the archi
     */
    public int getArchi() {
        return archi;
    }

    /**
     * @param archi the archi to set
     */
    public void setArchi(int archi) {
        this.archi = archi;
    }

    /**
     * @return the dire
     */
    public int getDire() {
        return dire;
    }

    /**
     * @param dire the dire to set
     */
    public void setDire(int dire) {
        this.dire = dire;
    }

    /**
     * Sobreescribe el método, recupera la ruta y cuenta los archivos y
     * directorios, los acumula y muestra el total de cada uno. Para mostrarlos
     * en consola, recupera el numero, le concatena si es archivo o directorio y
     * muestra el nombre.
     */
    @Override
    public void run() {
        File f = new File(getRuta());
        File[] fichero = f.listFiles();
        for (int i = 0; i < fichero.length; i++) {
            if (fichero[i].isFile()) {
                archi++;
                System.out.println(getArchi() + "archivo" + fichero[i].getName());
                archi = getArchi();
            } else if (fichero[i].isDirectory()) {
                dire++;
                System.out.println(getDire() + "directorio" + fichero[i].getName());
                dire = getDire();
            }
        }
    }
}




/**
 * Lista archivos
 * File f = new File(getRuta());
 * File[] fichero = f.listFiles();
 * for (int i = 0; i < fichero.length; i++) 
 * {fichero[i].getName();
 * System.out.println(fichero[i].getName());
 * }
 */
