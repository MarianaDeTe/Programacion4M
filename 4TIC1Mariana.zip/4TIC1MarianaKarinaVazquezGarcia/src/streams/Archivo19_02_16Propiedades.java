/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package streams;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;

/**
 *
 * @author Alumnos
 */
public class Archivo19_02_16Propiedades {

    private String listado = "";

    public void Archivo(String ruta) {
        File arch = new File(ruta);
        File[] lis = arch.listFiles();
        String a[] = new String[lis.length];

        for (int x = 0; x < lis.length; x++) {
            a[x] = lis[x].getName().concat(lis[x].isFile() ? "   Archivo" : "   Directorio");
            listado = listado + a[x] + " \n";
        }
    }

    public void Binario() {
        try {
            DataOutputStream arcSalida = new DataOutputStream(new FileOutputStream("Binario archivos.dat"));
            arcSalida.writeUTF(listado);
            arcSalida.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void PDF() {
        try {
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("PDF Archivos.pdf"));
            doc.open();//
            doc.add(new Paragraph(listado));
            doc.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void Texto() {
        try {
            FileWriter archivo = new FileWriter("Texto Archivos.txt");
            archivo.write(listado);
            archivo.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
