/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package socketserver;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.JOptionPane;

/**
 *
 * @author APOCALIPSIS
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        String pregunta, respuesta="hola";

        try{
            ServerSocket server=new ServerSocket(5000);
            while(true){
            try{
                Socket cliente=server.accept();

                JOptionPane.showMessageDialog(null, "El cliente se conecto");

                DataInputStream recibe=new DataInputStream(cliente.getInputStream());
                DataOutputStream envia=new DataOutputStream(cliente.getOutputStream());

                pregunta=recibe.readUTF();


               envia.writeUTF(pregunta);

            }catch(Exception r){
            JOptionPane.showMessageDialog(null, "Error al crear el socket cliente");
            }
            }
        }catch(Exception f){
            JOptionPane.showMessageDialog(null, "Error al crear el socket servidor");
        }

    }

}
