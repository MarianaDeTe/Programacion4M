/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicaciones;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.JOptionPane;

/**
 *
 * @author Vazquez Garcia Mariana Karina
 */
public class PdfServidorp {
    private String nombre;
    
    public String getNombre() {
        return nombre + ".pdf";
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void inicia() {
        nombre = JOptionPane.showInputDialog(null, "Ingresa el nombre del archivo");
        /**
         * Agrega un nombre al servidor, ya que el nombre recuperado del cliente
         * aun no se envia, sin esta variable envia un null.
         * 
         * 
         * 
         * NOTA= no se lo debo quitar, hasta que invistige la recuperacion del
         * nombre del cliente
         */
        try {
            ServerSocket servidor = new ServerSocket(4000);
            //carpeta de ServidorPdf esta dentro del proyecto
            String path = "G:\\Rojita\\4TIC1\\Desarrollo de Aplicaciones II\\4TIC1MarianaKarinaVazquezGarcia\\ServidorPDF\\" + getNombre();
            Socket cliente = servidor.accept();
            InputStream llegada = cliente.getInputStream();
            FileOutputStream destino = new FileOutputStream(path);
            byte[] buffer = new byte[1024];
            int len;
            while ((len = llegada.read(buffer)) > 0) {
                destino.write(buffer, 0, len);
            }
            destino.close();
            cliente.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
/**INTERFACE
 * metodos abstractos y constantes, con la finalidad de que no se pueden
 * modificar.
 */
