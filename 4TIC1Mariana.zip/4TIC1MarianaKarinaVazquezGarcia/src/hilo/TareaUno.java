/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilo;

/**Vazquez Garcia
 *
 * La clase Thread, que implementa la interfaz Runnable, de forma resumida:
 * 
 * Public class Thread extends Object implements Runnable
 */
public class TareaUno implements Runnable{
    public void run(){
        for (int i = 0; i <= 100; i++) {
            System.out.println("Numero" + numero);
        }
    }
    int numero;
}
