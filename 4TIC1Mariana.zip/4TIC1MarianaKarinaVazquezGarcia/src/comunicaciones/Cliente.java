/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicaciones;

import java.io.DataInputStream;
import java.net.Socket;

/**
 *
 * @author Vazquez Garcia Mariana Karina
 */
public class Cliente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
            Socket cliente = new Socket("localhost",5000);//direccion y puerto
            DataInputStream di = new DataInputStream(cliente.getInputStream());
            /**
             * Data = leer de un flujo de entrada
             * 
             */
            System.out.println(di.readUTF());
            di.close();//se tiene que cerrar cada flujo
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
}
