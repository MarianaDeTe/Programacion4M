/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilo;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Vazquez Garcia Mariana
 *
 * import java.util.logging.Logger y import java.util.logging.Level, se pueden
 * emplear para dar mensajes de información, estados de los datos o inclusive
 * errores ocurridos durante la ejecución SEVERE: Nivel de mayor prioridad, para
 * indicar errores.
 */
public class PruebaRunnable {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        TareaUno obj = new TareaUno();
        obj.numero = 5;

        Thread hilo1 = new Thread(obj);
        TareaUno obj2 = new TareaUno();
        obj2.numero = 10;

        Thread hilo2 = new Thread(obj2);
        hilo1.start();
        hilo2.start();

        try {
            hilo1.sleep(1000);//dormir el hilo
            hilo2.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(PruebaRunnable.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
