/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;

/**
 * Mariana Karina Vazquez Garcia
 */
public class AliniacionEnPDF {

    /**
     * Mariana Kariona Vazquez Garcia
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            Paragraph parrafo = new Paragraph("Titulo del documento");
            Document documento = new Document(PageSize.LETTER);
            PdfWriter.getInstance(documento, new FileOutputStream("alineacion de parrafo.pdf"));//titulo del pdf
            documento.open();//abre el documento
            parrafo.setAlignment(Element.ALIGN_CENTER);
            documento.add(parrafo);
            for (int i = 0; i <= 20; i++) {
                Paragraph p = new Paragraph("Parrafo No. " + i );//genera parrafos
                if (i%2==0) {//optiene pares
                    p.setAlignment(Element.ALIGN_RIGHT);
                    documento.add(p);//agrega parrafos al documento 
                }else{
                    p.setAlignment(Element.ALIGN_LEFT);//alinea el parrafo
                    documento.add(p);
                }
            }
            documento.close();//cierra el documento
        } catch (Exception e) {
            e.printStackTrace();
        }
    }   
}
