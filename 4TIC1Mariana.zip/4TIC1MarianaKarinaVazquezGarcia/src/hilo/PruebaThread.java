/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilo;

/**
 *Vazquez Garcia Mariana Karina
 */
public class PruebaThread {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Crea un objeto de la clase.
        ClaseThread hilo1 = new ClaseThread();
        ClaseThread hilo2 = new ClaseThread();
        ClaseThread hilo3 = new ClaseThread();
        
        hilo1.setName("Uno");
        hilo2.setName("Dos");
        hilo3.setName("Tres");
        
        hilo1.start();//inicia el hilo
        hilo2.start();
        hilo3.start();
    }
    
}
