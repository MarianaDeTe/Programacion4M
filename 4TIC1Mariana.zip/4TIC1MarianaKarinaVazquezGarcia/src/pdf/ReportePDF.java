/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfWriter;
import conexiones.Conexion;
import java.io.FileOutputStream;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * Mariana Karina Vazquez Garcia
 */
public class ReportePDF {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /**
         * Cuando se abre el documento, entra a la conexion y si la ruta es
         * correcta ejecuta la sentencia y muestra los resultados, con ayuda de
         * un "while" sigue recorriendo la base hasta que encuentra mas
         * resultados
         */
        try {
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("reporte.pdf"));
            doc.open();
            Conexion objCon = new Conexion();
            Statement sentencia = objCon.obtenerConexion().createStatement();
            String sql = "SELECT * FROM persona";
            ResultSet resultados = sentencia.executeQuery(sql);
            /**
             * Con el reSultSet muestra los datos, se utiliza el while para que
             * muestre todos los datos que va encontrando
             */
            while (resultados.next()) {
                doc.add(new Phrase(resultados.getString("nombre") + " "));
                doc.add(new Phrase(resultados.getString("paterno") + " "));
                doc.add(new Phrase(resultados.getString("materno") + " " + "\n"));
            }
            doc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
