/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;

/**
 * Mariana Karina Vazquez Garcia
 */
public class MiPrimerPDF {

    public static void main(String args[]) {
        try {
            /**
             * Se crea un objeto que esta dentro de la clase document lo crea en
             * memoria, no de manera fisica
             */
            Document documento = new Document(PageSize.LETTER);//documento de tamaño carta
            PdfWriter.getInstance(documento, new FileOutputStream("primer.pdf"));
            /**
             * Con la clase FileOutputStream recibe una cadena de texto que
             * especifica el nombre del archivo.
             *
             * La clase Paragraph agrega parrafos, para agregar mas parrafos
             * solo se repite la linea de Paragraph.
             *
             * add es un metodo que crea el objeto y se lo manda
             */
            documento.open();//empiezas a tabrajar con el archivo
            documento.add(new Paragraph("Hola"));//crear una instancia anonima
            documento.add(new Paragraph("    Marian"));
            documento.close();//se ha terminado de utilizar
        } catch (Exception e) {
            /**
             * las excepciones son: que no se puede abrir, leer, modificar
             */
            e.printStackTrace();
        }
    }
}
