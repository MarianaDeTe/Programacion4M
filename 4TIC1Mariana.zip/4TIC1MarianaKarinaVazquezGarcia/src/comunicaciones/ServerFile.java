/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicaciones;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * Vazquez Garcia Mariana Karina
 */
public class ServerFile {

    public static void main(String[] args) {
        try {//atrapa IOExcepcion que son entrada o salida de dato
            ServerSocket servidor = new ServerSocket(4000);//puerto que escucha
            Scanner teclado = new Scanner(System.in);
            System.out.println("Ingresa el destino (path): ");
            /**
             * ruta donde se recibe la informacion
             *
             * se agrega un nombre con la extencion "ruta + \nombre.extencion"
             * \hola.txt \hola.png \hola."..."
             */
            String path = teclado.nextLine();
            Socket cliente = servidor.accept();//acepta el objeto y lo asigna a cliente
            InputStream llegada = cliente.getInputStream();//asigna flujo de entrada y se lo pasa a el objeto llegada
            FileOutputStream dcestino = new FileOutputStream(path);//salida a un archivo, recibe la ruta 
            byte[] buffer = new byte[1024];//maneja el tamaño del archivo
            int len;
            while ((len = llegada.read(buffer)) > 0) {//realiza una signacion, lee la llegada y la compara mientras no sea menor a 0            
                dcestino.write(buffer, 0, len);//cada vez que entrea al ciclo va a ir escribiendo datos.
            }
            dcestino.close();
            cliente.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
/**
 * DataOutputStream y OuputStream son para leer datos pero en OutputStream
 * utiliza bytes, pero es mas rapido.
 */
