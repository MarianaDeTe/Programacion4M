/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicaciones;

import java.io.FileInputStream;
import java.io.PrintStream;
import java.net.Socket;

/**
 * Vazquez Garcia Mariana Karina
 */
public class ListaServido {

    private String seleccion;

    public String getSeleccion() {
        return seleccion;
    }

    public void setSeleccion(String seleccion) {
        this.seleccion = seleccion;
    }

    public void envia() {
        try {
            Socket cliente = new Socket("localhost", 4000);
            PrintStream envio = new PrintStream(cliente.getOutputStream());
            String ruta = seleccion;
            FileInputStream origen = new FileInputStream(ruta);
            byte[] buffer = new byte[1024];
            int len;
            while ((len = origen.read(buffer)) > 0) {
                envio.write(buffer, 0, len);
            }
            envio.close();
            cliente.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
