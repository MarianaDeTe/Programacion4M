/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenDos;

import java.io.File;

/**
 *
 * @author Alumnos
 */
public class ArchivosConteo extends Thread{
    private String ruta;
    private int rep;
    private int norep;

    /**
     * @return the ruta
     */
    public String getRuta() {
        return ruta;
    }

    /**
     * @param ruta the ruta to set
     */
    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    /**
     * @return the rep
     */
    public int getRep() {
        return rep;
    }

    /**
     * @param rep the rep to set
     */
    public void setRep(int rep) {
        this.rep = rep;
    }

    /**
     * @return the norep
     */
    public int getNorep() {
        return norep;
    }

    /**
     * @param norep the norep to set
     */
    public void setNorep(int norep) {
        this.norep = norep;
    }
    
    @Override
    public void run() {
        File f = new File(getRuta());
        File[] fichero = f.listFiles();
        for (int i = 0; i < fichero.length; i++) {
            if (f.exists()) {
                rep++;
                System.out.println(fichero[i].getName());
                System.out.println(getRep() + "arch");
                rep=getRep();
            }else{
                norep++;
                System.out.println(getNorep() + "dir");
                norep=getNorep();
            }
//            System.out.println(fichero[i].getName());
//            if (fichero[i].isFile()) {
//                rep++;
//                System.out.println(getRep() + "arch");
//                rep=getRep();
//            } else if (fichero[i].isDirectory()) {
//                norep++;
//                System.out.println(getNorep() + "dir");
//                norep=getNorep();
//            }
        }
    }
}
