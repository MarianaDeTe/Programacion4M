/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pdf;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;

/**
 * Mariana Karina Vazquez Garcia
 */
public class FuentePDF {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            Document documento = new Document(PageSize.LETTER);
            Font fuente = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD);
            fuente.setColor(BaseColor.BLUE);//cambia el color de la letra
            PdfWriter.getInstance(documento, new FileOutputStream("color.pdf"));

            documento.open();
            Paragraph parrafo = new Paragraph();
            parrafo.setFont(fuente);
            parrafo.setAlignment(Element.ALIGN_CENTER);//alinea el parrafo
            parrafo.add("Parrafo");
            documento.add(parrafo);//permite que se agrege al documento
            documento.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
