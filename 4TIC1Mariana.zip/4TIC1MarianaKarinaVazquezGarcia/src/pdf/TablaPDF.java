/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;

/**
 * Mariana Karina Vazquez Garcia
 */
public class TablaPDF {

    /**
     * Si no se agrega una celda, no agrega ninguna, el numero de columnas tiene
     * que ser el mismo numero de celdas iniciales que se agregan.
     *
     * @param args
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("Tabla.pdf"));
            doc.open();
            PdfPTable miTabla = new PdfPTable(3);//crea columnas
            PdfPCell celda = new PdfPCell();//permite manejar las celdas
            celda.setColspan(3);//combinar las celdas
            Paragraph parrafo = new Paragraph("Titulo");
            parrafo.setAlignment(Element.ALIGN_CENTER);
            celda.addElement(parrafo);
            miTabla.addCell(celda);//agrega celdas
            miTabla.addCell("celda 1");
            miTabla.addCell("celda 2");
            miTabla.addCell("celda 3");
            doc.add(miTabla);
            doc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
