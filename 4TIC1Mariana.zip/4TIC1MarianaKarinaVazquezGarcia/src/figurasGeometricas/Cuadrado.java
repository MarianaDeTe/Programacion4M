/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package figurasGeometricas;

/**
 * Mariana Karina Vazquez Garcia
 */
public class Cuadrado extends Figura {

    /**
     * extends permite heredar atributos y métodos de la clase padre.
     * 
     * @Override sobre escribe el método para hacer otra acción.
     */
    @Override
    public double obtenerArea() {
        return area = getCtdLados() * getCtdLados();
    }

    public double obtenergetPerimetro() {
        return perimetro = getValorLado() * 4;
    }

}
