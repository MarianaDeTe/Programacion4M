/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package figurasGeometricas;

/**
 * Mariana Karina Vazquez Garcia
 */
public class PruebaFigura {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Figura fig = new Cuadrado();
        /**
         * figura es abstracta, es por eso que se utiliza una clase hija, que
         * permita heredar los atributos, sin utilizar la clase figura
         */
        Triangulo tri = new Triangulo();
        tri.setValorLado(8);
        System.out.println("Area Triangulo = " + tri.obtenerArea());

        Cuadrado cu = new Cuadrado();
        cu.setCtdLados(3);
        System.out.println("Area Cuadrado = " + cu.obtenerArea());
    }
}
