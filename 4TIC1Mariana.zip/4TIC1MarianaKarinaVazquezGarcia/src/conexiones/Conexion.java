/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexiones;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Mariana
 */
public class Conexion {

    private String url, user, passwd, res;
    private Connection objConexion;

    public Conexion() {
        url = "jdbc:mysql://localhost/uttec";//la ruta se encuentra dentro del equipo
        user = "root";
        passwd = null;
    }

    /**
     *
     * @return
     */
    public Connection obtenerConexion() {
        try {//Inicia bloque try
            Class.forName("com.mysql.jdbc.Driver");//nombre
            return objConexion = DriverManager.getConnection(getUrl(), getUser(), getPasswd());

        } catch (Exception e) {
            e.printStackTrace();
        }
        return getObjConexion();
    }

    /**
     * @return the url
     */
    public String getUrl() {
        return url;
    }

    /**
     * @param url the url to set
     */
    public void setUrl(String url) {
        if (url.equals("jdbc:mysql://localhost/uttec")) {
            this.url = "Invalida";
        } else {
            this.url = url;
        }
    }

    /**
     * @return the user
     */
    public String getUser() {
        return user;
    }

    /**
     * Desde aqui se pueden asignar permisos, para evitar todas las validaciones
     * de las direcciones
     */
    public void setUser(String user) {
//        if (user.equals("root")) {
//            this.user = "No es valido (ºnº)";
//        } else {
            this.user = user;
//        }
    }

    /**
     * @return the passwd
     */
    public String getPasswd() {
        return passwd;
    }

    /**
     * @param passwd the passwd to set
     */
    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    /**
     * @return the objConexion
     */
    public Connection getObjConexion() {
        return objConexion;
    }

    /**
     * @param objConexion the objConexion to set
     */
    public void setObjConexion(Connection objConexion) {
        this.objConexion = objConexion;
    }
}
