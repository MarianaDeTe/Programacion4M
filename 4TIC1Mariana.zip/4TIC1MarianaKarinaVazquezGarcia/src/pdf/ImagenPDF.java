/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;

/**
 * Mariana Karina Vazquez Garcia
 */
public class ImagenPDF {

    /**
     * La imagen tiene que estar ubicada en la raiz del proyecto, para que la
     * clase la encuentre
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("imagen.pdf"));
            doc.open();
            Image img = Image.getInstance("Penguins.jpg");//nombre de la imagen
            doc.add(img);
            Image imgDos = Image.getInstance("Penguins.jpg");
            imgDos.scalePercent(50);//define un tamaño de imagen
            doc.add(imgDos);
            Image imgTres = Image.getInstance("Penguins.jpg");
            imgTres.scalePercent(10);
            imgTres.setAbsolutePosition(50, 10);//x,y  la posicion comienza desde el borde inferior izquierdo
            doc.add(imgTres);
            doc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
