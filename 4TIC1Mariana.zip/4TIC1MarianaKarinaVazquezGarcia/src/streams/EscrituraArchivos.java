/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package streams;

import java.io.FileWriter;

/**
 *
 * Vazquez Garcia Mariana
 */
public class EscrituraArchivos {

    /**
     * Sin el boolean lo que hace es sobre escribe, al agregar un true guarda la
     * informacion anterior, mas la nueva.
     * 
     * se crea un texto "nuevo" sin el true en el constructor
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            FileWriter archivo = new FileWriter("archivo.txt", true);
            archivo.write("Es otra prueba ");//se cambia el texto
            archivo.write(55);//codigo aski
            archivo.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
