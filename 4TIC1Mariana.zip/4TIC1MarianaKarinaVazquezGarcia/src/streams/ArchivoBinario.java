/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package streams;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * Vazquez Garcia Mariana Karina
 */
public class ArchivoBinario {

    /**
     * la extencion te dice con que programa se va a abrir.
     */
    public static void main(String[] args) {

//        try {
//            DataOutputStream arcSalida = new DataOutputStream(new FileOutputStream("arc.dat"));//ingresar datos
//            arcSalida.writeInt(135);
//            arcSalida.writeDouble(45.6534);
//            arcSalida.writeUTF("Mariana Karina");
//            arcSalida.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

        try {
            DataInputStream arcLeer = new DataInputStream(new FileInputStream("arc.dat"));//leer datos
            int i = arcLeer.readInt();
            double d = arcLeer.readDouble();
            String s = arcLeer.readUTF();//estandar de codificación
            System.out.println("Int " + i + " Double " + d + " Cadena " + s);
            arcLeer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
