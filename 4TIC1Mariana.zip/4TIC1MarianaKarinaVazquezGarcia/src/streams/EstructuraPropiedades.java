/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package streams;

import java.io.FileWriter;
import javax.swing.JOptionPane;

/**
 *
 * @author Alumnos
 */
public class EstructuraPropiedades {

    private String nombre;
    private String mensaje;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public void PruebaAgrega() {
        try {
            FileWriter archi = new FileWriter(getNombre(), true);
            if (archi.equals(null)) {
                JOptionPane.showMessageDialog(null, "El archivo no existe", "Error (°n°)", JOptionPane.ERROR_MESSAGE);
            } else {
                FileWriter archivo = new FileWriter(getNombre(), true);
                archivo.write(getMensaje());
                archivo.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void PruebaNuevo() {
        try {
            FileWriter archi = new FileWriter(getNombre());
            if (archi.equals(null)) {
                JOptionPane.showMessageDialog(null, "El archivo no existe", "Error (°n°)", JOptionPane.ERROR_MESSAGE);
            } else {
                FileWriter archivo = new FileWriter(getNombre());
                archivo.write(getMensaje());
                archivo.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
