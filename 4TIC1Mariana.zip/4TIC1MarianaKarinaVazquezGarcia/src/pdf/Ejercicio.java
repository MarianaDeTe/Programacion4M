/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import conexiones.Conexion;
import java.io.FileOutputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 * Mariana Karina Vazquez Garcia
 */
public class Ejercicio {

    private int datoN;//recupera el numero que ingresan
    private String nombre;
    private String paterno;
    private String materno;
    private String curp;
//    private String sql;

    public int getDatoN() {
        if (datoN == 0) {
            JOptionPane.showMessageDialog(null, "No existe ese ID", "Error (°n°)", JOptionPane.ERROR_MESSAGE);
        }
        return datoN;
    }

    public void setDatoN(int datoN) {
        this.datoN = datoN;
    }

    public String getNombre() {
        if (nombre == null) {//si no encuentra los datos en la base manda un mensaje de error
            JOptionPane.showMessageDialog(null, "No existe el nombre", "Error (°n°)", JOptionPane.ERROR_MESSAGE);
        }
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPaterno() {
        if (paterno == null) {
            JOptionPane.showMessageDialog(null, "No existe el a. paterno", "Error (°n°)", JOptionPane.ERROR_MESSAGE);
        }
        return paterno;
    }

    public void setPaterno(String paterno) {
        this.paterno = paterno;
    }

    public String getMaterno() {
        if (materno == null) {
            JOptionPane.showMessageDialog(null, "No existe el a. materno", "Error (°n°)", JOptionPane.ERROR_MESSAGE);
        }
        return materno;
    }

    public void setMaterno(String materno) {
        this.materno = materno;
    }

    public String getCurp() {
        if (curp == null) {
            JOptionPane.showMessageDialog(null, "No existe el curp", "Error (°n°)", JOptionPane.ERROR_MESSAGE);
        }
        return curp;
    }

    public void setCurp(String curp) {
        this.curp = curp;
    }

    /**
     * Dentro del método se crea un objeto para generar el PDF y otro para
     * realizar la conexion, utilizando una sentencia string para buscar por id.
     *
     * pageSize indica el tamaño.
     *
     * getInstance instancia el objeto para poder escribir
     */
    public void BuscarI() {
        try {
            Document doc = new Document(PageSize.LETTER);//genera un objeto para el documento
            PdfWriter.getInstance(doc, new FileOutputStream("Reporte de busquedas.pdf"));

            doc.open();

            Conexion objCon = new Conexion();
            Statement sentencia = objCon.obtenerConexion().createStatement();
            String sql = "SELECT * FROM persona WHERE personaId=" + datoN;
            ResultSet resultados = sentencia.executeQuery(sql);

            PdfPCell celda = new PdfPCell();
            celda.setColspan(2);//combina el número de celdas especificadas dentro del parentesis
            Paragraph parrafo = new Paragraph("Registro encontrado");
            parrafo.setAlignment(Element.ALIGN_CENTER);
            celda.addElement(parrafo);

            while (resultados.next()) {
                PdfPTable miTabla = new PdfPTable(2);
                miTabla.addCell(celda);
                /**
                 * se concatena el nombre, recuperando lo que encuentra de la
                 * base de datos
                 */
                miTabla.addCell(new Phrase(resultados.getString("nombre") + " " + resultados.getString("paterno") + " " + resultados.getString("materno")));
                miTabla.addCell(new Phrase(resultados.getString("curp")));
                //la clase Phrase representa un cadena de palabras, que se compone de objetos
                doc.add(miTabla);
            }
            doc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void BuscarP() {
        try {
            /**
             * tiene un constructor sobrecargado, es decir, varias formas de
             * inicializar
             */
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("Reporte de busquedas.pdf"));
            doc.open();

            Conexion objCon = new Conexion();
            Statement sentencia = objCon.obtenerConexion().createStatement();
            String sql = "SELECT * FROM persona WHERE Nombre='" + nombre + "' or paterno='"
                    + paterno + "' or materno='" + materno + "'";
            ResultSet resultados = sentencia.executeQuery(sql);

            PdfPCell celda = new PdfPCell();
            celda.setColspan(2);
            /**
             * prepara el contenido que tendra el PDF y el constructor que
             * también es sobrecargado
             */
            Paragraph parrafo = new Paragraph("Registros encontrados");
            Paragraph no = new Paragraph("Nombre");
            Paragraph cu = new Paragraph("Curp");

            parrafo.setAlignment(Element.ALIGN_CENTER);
            no.setAlignment(Element.ALIGN_MIDDLE);
            cu.setAlignment(Element.ALIGN_RIGHT);
            celda.addElement(parrafo);

            PdfPTable Tabla = new PdfPTable(2);
            Tabla.addCell(celda);
            Tabla.addCell(no);
            Tabla.addCell(cu);
            doc.add(Tabla);

            while (resultados.next()) {
                PdfPTable miTabla = new PdfPTable(2);

                miTabla.addCell(new Phrase(resultados.getString("nombre") + " " + resultados.getString("paterno") + " " + resultados.getString("materno")));
                miTabla.addCell(new Phrase(resultados.getString("curp")));

                doc.add(miTabla);
            }
            doc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void BuscarGM() {
        try {
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("Reporte de busquedas.pdf"));
            doc.open();

            Conexion objCon = new Conexion();
            Statement sentencia = objCon.obtenerConexion().createStatement();

            String sql = "SELECT * FROM persona WHERE personaId=" + datoN + " or Nombre='" + nombre + "' or paterno='"
                    + paterno + "' or materno='" + materno
                    + "' and curp like'__________M%'";

            ResultSet resultados = sentencia.executeQuery(sql);
            PdfPCell celda = new PdfPCell();
            celda.setColspan(2);

            Paragraph parrafo = new Paragraph("Registros encontrados");
            Paragraph no = new Paragraph("Nombre");
            Paragraph cu = new Paragraph("Curp");

            parrafo.setAlignment(Element.ALIGN_CENTER);
            no.setAlignment(Element.ALIGN_MIDDLE);
            cu.setAlignment(Element.ALIGN_RIGHT);
            celda.addElement(parrafo);

            PdfPTable Tabla = new PdfPTable(2);
            Tabla.addCell(celda);
            Tabla.addCell(no);
            Tabla.addCell(cu);
            doc.add(Tabla);

            while (resultados.next()) {
                PdfPTable miTabla = new PdfPTable(2);

                miTabla.addCell(new Phrase(resultados.getString("nombre") + " " + resultados.getString("paterno") + " " + resultados.getString("materno")));
                miTabla.addCell(new Phrase(resultados.getString("curp")));

                doc.add(miTabla);
            }
            doc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void BuscarGH() {

        try {
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("Reporte de busquedas.pdf"));
            doc.open();

            Conexion objCon = new Conexion();
            Statement sentencia = objCon.obtenerConexion().createStatement();
            String sql = "SELECT * FROM persona WHERE personaId=" + datoN + " or Nombre='" + nombre + "' or paterno='"
                    + paterno + "' or materno='" + materno
                    + "' and curp like'__________H%'";
            ResultSet resultados = sentencia.executeQuery(sql);

            PdfPCell celda = new PdfPCell();
            celda.setColspan(2);

            Paragraph parrafo = new Paragraph("Registros encontrados");
            Paragraph no = new Paragraph("Nombre");
            Paragraph cu = new Paragraph("Curp");

            parrafo.setAlignment(Element.ALIGN_CENTER);
            no.setAlignment(Element.ALIGN_MIDDLE);
            cu.setAlignment(Element.ALIGN_RIGHT);
            celda.addElement(parrafo);

            PdfPTable Tabla = new PdfPTable(2);
            Tabla.addCell(celda);
            Tabla.addCell(no);
            Tabla.addCell(cu);
            doc.add(Tabla);

            while (resultados.next()) {
                PdfPTable miTabla = new PdfPTable(2);

                miTabla.addCell(new Phrase(resultados.getString("nombre") + " " + resultados.getString("paterno") + " " + resultados.getString("materno")));
                miTabla.addCell(new Phrase(resultados.getString("curp")));

                doc.add(miTabla);
            }
            doc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean getPersonaByPreparedStatement(String nom) {
        //Un PreparedStatement se utiliza para sentencias que se tienen que precompilar
        try {
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("Reporte de busquedas.pdf"));
            doc.open();
//            String sql = null;
//            
//            int menu = 0;
//            switch (menu) {
//                case 1:
//                    datoN = getDatoN();
//                    sql = "SELECT * FROM persona WHERE personaId=" + datoN + " and curp like'__________M%'";
//                    break;
//                case 2:
//                    nombre = getNombre();
//                    sql = "SELECT * FROM persona WHERE nombre='" + nombre + "' and curp like'__________M%'";
//                    break;
//                case 3:
//                    paterno = getPaterno();
//                    sql = "SELECT * FROM persona WHERE paterno='" + paterno + "' and curp like'__________M%'";
//                    break;
//                case 4:
//                    materno = getMaterno();
//                    sql = "SELECT * FROM persona WHERE materno='" + materno + "' and curp like'__________M%'";
//                    break;
//                default:
//                    JOptionPane.showMessageDialog(null, "No se encontraron datos", "ERROR (°n°)", JOptionPane.ERROR_MESSAGE);
//                    break;
//            }
            String sql = "SELECT * FROM Persona where nombre=? and curp like'__________M%'";
            Conexion objCon = new Conexion();
            PreparedStatement ps = objCon.obtenerConexion().prepareStatement(sql);
            ps.setString(2, nom);
            ResultSet resultados = ps.executeQuery();

            while (resultados.next()) {
                PdfPTable miTabla = new PdfPTable(2);

                miTabla.addCell(new Phrase(resultados.getString("nombre") + " " + resultados.getString("paterno") + " " + resultados.getString("materno")));
                miTabla.addCell(new Phrase(resultados.getString("curp")));

                doc.add(miTabla);
//                nombre = registro.getString(2);
//                paterno = registro.getString("paterno");
//                materno = registro.getString("materno");
//                curp = registro.getString("curp");
            }
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }
}
