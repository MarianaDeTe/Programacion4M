/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package streams;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import javax.swing.JOptionPane;

/**
 *
 * @author Alumnos
 */
public class NumeroEjercicioPropiedades {

    private int numero;
    String resultado;
    boolean primo;
    int con, acu = 0;

//    public void Calcular() {
//        for (int i = 2; i <= getNumero(); i++) {
//            primo = true;
//            for (int j = 2; j < i; j++) {
//                if (i % j == 0) {
//                    primo = false;
//                }
//            }
//            if (primo) {
//                resultado = acu + i + "\n";
//            }
//        }
//    }

    public void Pdf() {
//        Calcular();
        try {
            Document documento = new Document(PageSize.LETTER);
            PdfWriter.getInstance(documento, new FileOutputStream("Número.pdf"));
            documento.open();
            documento.add(new Paragraph(resultado));
            documento.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void Texto() {
//        Calcular();
        try {
            FileWriter archivo = new FileWriter("Número.txt");
            archivo.write(resultado);
            archivo.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void Binario() {
//        Calcular();
esPrimo(getNumero());
        try {
            DataOutputStream arcSalida = new DataOutputStream(new FileOutputStream("Número.dat"));
            arcSalida.writeUTF(resultado);
            arcSalida.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @return the numero
     */
    public int getNumero() {
        return numero;
    }

    /**
     * @param numero the numero to set
     */
    public void setNumero(int numero) {
        this.numero = numero;
    }

    public static boolean esPrimo(int numero) {
        int contador = 2;
        boolean primo = true;
        while ((primo) && (contador != numero)) {
            if (numero % contador == 0) {
                primo = false;
            }
            contador++;
        }
        return primo;
    }
}
