/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;

/**
 * Mariana Karina Vazquez Garcia
 */
public class GenerarTablaPDF {

    int col;
    int fil;

    /**
     * @return the col
     */
    public int getCol() {
        return col;
    }

    /**
     * @param col the col to set
     */
    public void setCol(int col) {
        this.col = col;
    }

    /**
     * @return the fil
     */
    public int getFil() {
        return fil;
    }

    /**
     * @param fil the fil to set
     */
    public void setFil(int fil) {
        this.fil = fil;
    }

    public void RecuperaTabla() {

        try {
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("Tablap.pdf"));
            doc.open();
            PdfPTable miTabla = new PdfPTable(getCol());
            for (int i = 0; i <= getFil() * getCol(); i++) {
                miTabla.addCell(" " + i + " ");
            }
            doc.add(miTabla);

            doc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
