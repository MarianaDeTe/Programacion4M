/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package figurasGeometricas;

/**
 * Mariana Karina Vazquez Garcia
 *
 * abstract es una clase que declara la existencia de métodos pero no los
 * utiliza.
 *
 * una clase abstracta no se puede instanciar pero si se puede heredar, las
 * clases hija son las encargadas de agregar la funcionalidad a los métodos
 */
public abstract class Figura {

    double area;
    double perimetro;
    int ctdLados;
    int ctdAngulos;
    String nombre;
    double valorLado;

    /**
     * @return the area
     */
    public double getArea() {
        return area;
    }

    /**
     * @param area the area to set
     */
    public void setArea(double area) {
        this.area = area;
    }

    /**
     * @return the perimetro
     */
    public double getPerimetro() {
        return perimetro;
    }

    /**
     * @param perimetro the perimetro to set
     */
    public void setPerimetro(double perimetro) {
        this.perimetro = perimetro;
    }

    /**
     * @return the ctdLados
     */
    public int getCtdLados() {
        return ctdLados;
    }

    /**
     * @param ctdLados the ctdLados to set
     */
    public void setCtdLados(int ctdLados) {
        this.ctdLados = ctdLados;
    }

    /**
     * @return the ctdAngulos
     */
    public int getCtdAngulos() {
        return ctdAngulos;
    }

    /**
     * @param ctdAngulos the ctdAngulos to set
     */
    public void setCtdAngulos(int ctdAngulos) {
        this.ctdAngulos = ctdAngulos;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the valorLado
     */
    public double getValorLado() {
        return valorLado;
    }

    /**
     * @param valorLado the valorLado to set
     */
    public void setValorLado(double valorLado) {
        this.valorLado = valorLado;
    }

    public abstract double obtenerArea();

    public abstract double obtenergetPerimetro();

}
