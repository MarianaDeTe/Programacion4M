/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MVC;

import java.awt.FlowLayout;
import javax.swing.JApplet;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;

/**
 *
 * @author Alumnos
 */
public class MVCDemo extends JApplet {

    private JButton jbtController = new JButton("Muestra Controlador");
    private JButton jbtView = new JButton("Muestra Vista");
    private ModeloCirculo model = new ModeloCirculo();

    public MVCDemo() {
        setLayout(new FlowLayout());
        add(jbtController);
        add(jbtView);
        
        jbtController.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Controller");
                ControladorCirculo controller = new ControladorCirculo();
                controller.setModel(model);
                frame.add(controller);
                frame.setSize(200, 200);
                frame.setVisible(true);
            }
        });
        jbtView.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("View");
                VistaCirculo controller = new VistaCirculo();
                controller.setModel(model);
                frame.add(controller);
                frame.setSize(200, 200);
                frame.setLocation(200, 200);
                frame.setVisible(true);
            }
        });
    }
}
