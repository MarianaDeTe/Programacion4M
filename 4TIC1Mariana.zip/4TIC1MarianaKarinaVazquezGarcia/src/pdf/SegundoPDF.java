/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;

/**
 * Mariana Karina Vazquez Garcia
 */
public class SegundoPDF {

    public static void main(String args[]) {
        try {
            Rectangle dimension = new Rectangle(100f, 200f);//tamaño
            Document documento = new Document(dimension, 5, 10, 20, 10);//margen
            /**
             * izquierdo,derecho arriba, abajo
             */
            PdfWriter.getInstance(documento, new FileOutputStream("segundoPdf.pdf"));
            /**
             * FileOutputStream es un fichero, que almace información
             */
            documento.open();
            for (int i = 0; i <= 10; i++) {
                documento.add(new Paragraph("Mariana " + i));
            }
            documento.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
