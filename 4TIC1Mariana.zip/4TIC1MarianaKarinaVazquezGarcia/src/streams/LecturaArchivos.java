/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package streams;

import java.io.FileReader;

/**
 *
 * @author Alumnos
 */
public class LecturaArchivos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
            FileReader archivo = new FileReader("archivo.txt");
            int valor = archivo.read();
            while(valor != -1){
                System.out.print((char) valor);
                valor = archivo.read();
            }
            archivo.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
}
