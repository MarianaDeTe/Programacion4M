/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicaciones;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Alumnos
 */
public class ListaClient {

    String seleccion;

    public void envia() {
        try {
            ServerSocket servidor = new ServerSocket(4000);//puerto que escucha
            String path = "";
            Socket cliente = servidor.accept();//acepta el objeto y lo asigna a cliente
            InputStream llegada = cliente.getInputStream();//asigna flujo de entrada y se lo pasa a el objeto llegada
            FileOutputStream dcestino = new FileOutputStream(path);
            byte[] buffer = new byte[1024];//arreglo de bytes
            int len;
            /**
             * el clico le asigna a la variable len lo que lee del origen y lo
             * compara mientras sea mayor a cero lo va enviando, hasta que
             * termine de leer todo el archivo; una vez que termina el cliclo se
             * cierra el objeto y el socket
             */
            while ((len = llegada.read(buffer)) > 0) {
                dcestino.write(buffer, 0, len);
            }
            dcestino.close();
            cliente.close();
        } catch (IOException ex) {
            Logger.getLogger(ClienteFile.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
