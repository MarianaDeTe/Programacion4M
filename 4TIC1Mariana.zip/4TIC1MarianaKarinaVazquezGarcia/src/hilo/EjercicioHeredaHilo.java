/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilo;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;

/**
 * Vazquez Garcia Mariana Karina
 *
 * Para que una aplicación pueda lanzar un hilo especifico, tiene que escribir
 * la clase hilo derivada de Thread y sobreescribir el método run heredado por
 * ésta, con la finalidad de especificar la tarea que tiene que realizar el
 * hilo.
 *
 */
public class EjercicioHeredaHilo extends Thread {

    private String mensaje;
    int tipo;

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public void PDF() {
        try {
            Document documento = new Document(PageSize.LETTER);
            PdfWriter.getInstance(documento, new FileOutputStream("PDF hilo.pdf"));
            documento.open();
            documento.add(new Paragraph(getMensaje()));
            documento.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void Texto() {
        try {
            FileWriter archi = new FileWriter("Texto hilo.txt");
            archi.write(getMensaje());
            archi.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void Binario() {
        try {
            DataOutputStream arcSalida = new DataOutputStream(new FileOutputStream("Binario hilo.dat"));
            arcSalida.writeUTF(getMensaje());
            arcSalida.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Ayuda ha reducir el codigo; cuando se creas una clase que hereda de otra
     * clase, herada todos sus metodos, propiedades y atrivutos. Override
     * significa que se estas sobre escribiendo un metodo de la clase padre, ya
     * sea para mejorar el metodo o para que se acople a la clase hija.
     */
    @Override
    public void run() {
//        EjercicioSinHilo esh = new EjercicioSinHilo();

        if (getTipo() == 1) {//aplica la condición
            Binario();
        } else if (getTipo() == 2) {
            Texto();
        } else if (getTipo() == 3) {
            PDF();
        }
    }
}
