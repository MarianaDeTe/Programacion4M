/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfWriter;
import conexiones.Conexion;
import java.io.FileOutputStream;
import java.sql.CallableStatement;
import java.sql.ResultSet;

/**
 * Mariana Karina Vazquez Garcia
 */
public class PropiedadesImagen {

    private int perId;
    private String nombre;
    private String paterno;
    private String materno;
    private String curp;
    private String Datos;

    public int getPerId() {
        return perId;
    }

    public void setPerId(int perId) {
        this.perId = perId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPaterno() {
        return paterno;
    }

    public void setPaterno(String paterno) {
        this.paterno = paterno;
    }

    public String getMaterno() {
        return materno;
    }

    public void setMaterno(String materno) {
        this.materno = materno;
    }

    public String getCurp() {
        return curp;
    }

    public void setCurp(String curp) {
        this.curp = curp;
    }

    public String getDatos() {
        return Datos;
    }

    public void setDatos(String Datos) {
        this.Datos = Datos;
    }

    /**
     * Utiliza un procedimiento almacenado donde recibe un parametro de tipo
     * entero y lo busca dentro de la primer columna en la segunda posicion de
     * la fila.
     *
     * @param xPersona
     * @return
     */
    public boolean getPersonaBuscaByCalleble(int xPersona) {
        try {
            Conexion objCon = new Conexion();
            CallableStatement cs = objCon.obtenerConexion().prepareCall("{Call buscarPersona(?)}");
            cs.setInt(1, xPersona);
            ResultSet registro = cs.executeQuery();

            while (registro.next()) {
                perId = registro.getInt(1);
                setNombre(registro.getString("Nombre"));
                setPaterno(registro.getString(3));
                setMaterno(registro.getString(4));
                setCurp(registro.getString(5));
            }
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public void CredencialPDF() {
        try {
            Document doc = new Document(PageSize.LETTER);
            Rectangle dimension = new Rectangle(450f, 250f);//posicionde la pagina
            doc = new Document(dimension, 50, 50, 20, 20);//margenes
            PdfWriter.getInstance(doc, new FileOutputStream("Credencial.pdf"));

            doc.open();

            Paragraph parrafo = new Paragraph();
            parrafo.setAlignment(Element.ALIGN_CENTER);
            parrafo.add("Universidad (°U°)");
            doc.add(parrafo);

            Image imgM = Image.getInstance("SITIO-MUSICA.jpg");//permite insertar una imagen
            imgM.scalePercent(20);
            imgM.setAbsolutePosition(40, 140);
            /**
             * mueve la imagen en posicion de un plano de las x,y tomando como
             * punto 0,0 la parte inferior izquierda
             */
            doc.add(imgM);//agrega la imagen al documento

            Paragraph nombre = new Paragraph();
            nombre.setAlignment(Element.ALIGN_RIGHT);
            nombre.add("\n\n" + getNombre() + " " + getPaterno() + " " + getMaterno());//concatena el nombre
            doc.add(nombre);

            Paragraph vig = new Paragraph("\n\n\n\n\nVigencia 2016");
            doc.add(vig);

            doc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
