use uttec;

create table Persona(personaId int auto_increment primary key, Nombre varchar(10), paterno varchar(10), materno varchar(10), curp char(18))engine = innodb;


insert into persona values(null,"Adriana","Garcia","Garcia","MKF000R567M9OLDFGH");
insert into persona values(null,"Luis","Garcia","Romero","LGRVBN456MHG2WEFGK");
insert into persona values(null,"Giovany","De la Luz","Colon","GDDLC4579DHRTQAZXS");
insert into persona values(null,"Eduardo","Mercado","Diaz","EDMAQWER14H369GHYP");
insert into persona values(null,"Karina","Vazquez","Garcia","KVGTYUIOP7M53LKJNM");
insert into persona values(null,"Mariana","Vazquez","Corona","MVGKJLIO45M98POQWE");
insert into persona values(null,"Bryan","Tepach","Reyes","BTRYUIOPM7H423NJHT");
insert into persona values(null,"Hugo","Lopez","Lopez","HLLGTFREDGH587HGBN");
insert into persona values(null,"Giovany","Vazquez","Corona","MVGKJLIO45H98POQWE");

delimiter -
create procedure insertarDatos(in personaId int, nombre varchar(10), paterno varchar(10), materno varchar(10), curp char(18))
begin
insert into Persona (personaId,Nombre,paterno,materno,curp) values (null,nombre,paterno,materno,curp);
end -
delimiter ;


delimiter -
create procedure eliminarPersona(in per int)
begin
delete from Persona  where personaId = per;
end -
delimiter ;


delimiter -
create procedure modificarPersona(in per int, nom varchar(10), pat varchar(10), mat varchar(10), cu char(18))
begin
update Persona set Nombre = nom where personaId = per;
update Persona set paterno = pat where personaId = per;
update Persona set materno = mat where personaId = per;
update Persona set curp = cu where personaId = per;
end -
delimiter ;


delimiter -
create procedure buscarPersona(in per int)
begin
select * from Persona where personaId = per;
end -
delimiter ;


delimiter -
create procedure todaPersona()
begin
select * from Persona;
end -
delimiter ;

delimiter -
create procedure resuelveCurp(in nom varchar(10))
begin
select * from Persona where nombre = nom and curp like"__________M%";
end -
delimiter ;