/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexiones;

import java.sql.SQLException;

/**
 *
 * @author Mariana
 */
public class PruebaConexion {

    /**
     * el método getCatalog(), recupera el nombre de la base
     */
    public static void main(String[] args) throws SQLException {
        Conexion obj = new Conexion();
        obj.obtenerConexion();
        System.out.println(obj.getObjConexion().getCatalog());
        // TODO code application logic here
    }

}
