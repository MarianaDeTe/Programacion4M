/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicaciones;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.JOptionPane;

/**
 * Mariana Karina
 */

public class ImagenServidor {
private String nombre;
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
//    public void recupera(){
//        String aux = "hola.jpg";
//        if (true) {
//            
//        }
//        nombre = aux;
//    }

    public void inicia() {
        nombre = JOptionPane.showInputDialog(null, "Ingresa el nombre del archivo");
        try {
            ServerSocket servidor = new ServerSocket(4000);
            //ruta para guardar lo que el cliente envia (path)
            String path = "G:\\Rojita\\4TIC1\\Desarrollo de Aplicaciones II\\4TIC1MarianaKarinaVazquezGarcia\\ServidorPDF\\" + getNombre();
            Socket cliente = servidor.accept();
            InputStream llegada = cliente.getInputStream();
            FileOutputStream destino = new FileOutputStream(path);
            byte[] buffer = new byte[1024];
            int len;
            while ((len = llegada.read(buffer)) > 0) {
                destino.write(buffer, 0, len);
            }
            destino.close();
            cliente.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        JOptionPane.showMessageDialog(null, "Transferencia exitoso", "Felicidades", JOptionPane.INFORMATION_MESSAGE);
    }
}
