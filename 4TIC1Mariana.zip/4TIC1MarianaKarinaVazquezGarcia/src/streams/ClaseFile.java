/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package streams;

import java.io.File;

/**
 *
 * Vazquez Garcia Mariana Karina
 */
public class ClaseFile {

    /**
     * Al constructor se le envia una cadena de texto
     * 
     * Se pregunta si es un archivo, en caso contrario se muestra un mensaje
     * de que no es un archivo.
     * 
     * La clase File lista archivos o directorios.
     * 
     * el signo de interrogacion es una condicion ternaria (devuelve verdadero o falso)
     */
    public static void main(String[] args) {
        // TODO code application logic here
        File archivo = new File("Hola.txt");
        File ar = new File("Karina.txt");
        System.out.println(archivo.isFile()?"Es un archivo (°U°)":"No es un archivo (°n°)");//archivo
        System.out.println(archivo.isDirectory()?"Es un directorio (°U°)":"No es un directorio (°n°)");//directorio
        System.out.println(archivo.isHidden()?"No esta oculto(°U°)":"Es oculto (°n°)");
        
        
        System.out.println(ar.mkdir());//directorio
        System.out.println(ar.isFile()?"Es un archivo (°U°)":"No es un archivo (°n°)");
        System.out.println(archivo.compareTo(archivo));
        System.out.println(archivo.getName());
        System.out.println(archivo.setWritable(true, true));
        System.out.println(archivo.canRead());
        System.out.println(archivo.isAbsolute());
        System.out.println(archivo.lastModified());
        System.out.println(archivo.renameTo(archivo));
        System.out.println(archivo.setLastModified(0));
        System.out.println(archivo.toURI());//ruta
        System.out.println(archivo.canWrite());
        System.out.println(archivo.canExecute());
        
        System.out.println(archivo.length());
    }
    
}
