/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 * Mariana Karina Vazquez Garcia
 */
public class PruebaPersona {

    public static void main(String[] args) {
        Persona objPer = new Persona();
        /**
         * este es un constructor y tiene que tener el mismo que la clase, y no
         * resive parametros
         */
        objPer.setNombre("Juanito");
        System.out.println(objPer.getNombre());

        Persona obj2 = new Persona(2);
        System.out.println(obj2.getCurp());

        Persona busca = new Persona();
        busca.getPersonaByPreparedStatement(5);
        System.out.println(busca.getNombre());

        Persona elimina = new Persona();
        elimina.getPersonaEliminaByPreparedStatement(4);
        System.out.println("Se ha eliminado el registro");

    }

}
