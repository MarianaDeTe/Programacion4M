/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package streams;

import java.io.File;
import java.io.FileReader;
import javax.swing.JOptionPane;

/**
 *
 * @author Alumnos
 */
public class LeerPropiedades {
    private String nombre, mensaje;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    
    public void LeerArchivo(){
        File archivo = new File(getNombre());
        if (!archivo.exists()) {
            JOptionPane.showMessageDialog(null, "No existe el archivo", "Error (°n°)", JOptionPane.ERROR_MESSAGE);
        }else{
            try{
            FileReader ar = new FileReader(archivo);
            int valor = ar.read();
//            mensaje = String.valueOf((char) valor);
            while(valor != -1){
                mensaje = mensaje + ((char) valor);
                valor = ar.read();
            }
            ar.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        }
    }

}
