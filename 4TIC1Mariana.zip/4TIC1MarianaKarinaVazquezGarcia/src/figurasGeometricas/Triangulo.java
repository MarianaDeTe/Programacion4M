/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package figurasGeometricas;

/**
 * Mariana Karina Vazquez Garcia
 */
public class Triangulo extends Figura {

    @Override
    public double obtenerArea() {
        return area = getValorLado() * getValorLado() / 2;
    }

    @Override
    public double obtenergetPerimetro() {
        return perimetro = getValorLado() * 3;
    }
}
